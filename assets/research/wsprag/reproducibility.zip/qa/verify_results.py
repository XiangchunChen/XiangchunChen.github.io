"""Independent result audit; run only after official screen opening has completed."""
import hashlib, itertools, json, math, pathlib, random, statistics, sys, re
from collections import Counter
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiment'))
import core, runner, screen

def independent_retrieve(t,cards):
 cs=[c for c in cards if c['architecture']==t['architecture']]; docs=[Counter(re.findall(r'[a-z0-9.\-]+',c['description'].lower())) for c in cs]; query=Counter(re.findall(r'[a-z0-9.\-]+',t['description'].lower())); n=len(docs); df=Counter(w for d in docs for w in d)
 def vec(d): return {w:v*(math.log((n+1)/(df[w]+1))+1) for w,v in d.items()}
 q=vec(query); qn=math.sqrt(sum(v*v for v in q.values())); tr={k:float(v.square().mean().sqrt()) for k,v in t['state'].items()}; scored=[]
 for c,d in zip(cs,docs):
  v=vec(d); dn=math.sqrt(sum(x*x for x in v.values())); sim=sum(x*v.get(w,0) for w,x in q.items())/(qn*dn) if qn and dn else 0; dist=statistics.mean(abs(tr[k]-c['weights_rms'][k])/(tr[k]+c['weights_rms'][k]+.01) for k in tr); scored.append((.8*sim+.2*(1-dist),c['source_id'],c))
 return [x[2] for x in sorted(scored,key=lambda x:(-x[0],x[1]))[:2]]
def independent_patch(state,patch):
 out={k:v.clone() for k,v in state.items()}
 for op in patch['operations']:
  tensor=state[op['tensor']]; rms=max(float(tensor.square().mean().sqrt()),.01); out[op['tensor']][tuple(op['index'])]+=op['coefficient']*rms
 return out

def main():
 opening=ROOT/'results/screen_opening.json'; results=ROOT/'results/screen_final.json'; summaryfile=ROOT/'results/screen_summary.json'
 if not all(p.exists() for p in (opening,results,summaryfile)): raise RuntimeError('Official screen opening and results must be complete before this audit')
 marker=json.loads(opening.read_text(encoding='utf8')); proposal=ROOT/'results/screen_proposals.jsonl'; rawlog=ROOT/'logs/raw_runs.jsonl'; journal=ROOT/'logs/screen_journal.jsonl'
 for key,path in [('proposal_sha256',proposal),('raw_log_sha256',rawlog),('journal_sha256',journal)]:
  if hashlib.sha256(path.read_bytes()).hexdigest()!=marker[key]: raise ValueError('opening hash mismatch: '+key)
 rows=[json.loads(x) for x in proposal.read_text(encoding='utf8').splitlines()]; calls=[json.loads(x) for x in rawlog.read_text(encoding='utf8').splitlines()]; observed=json.loads(results.read_text(encoding='utf8')); summary=json.loads(summaryfile.read_text(encoding='utf8'))
 cards=json.loads((ROOT/'results/archive_frozen.json').read_text(encoding='utf8')); lock=json.loads((ROOT/'results/screen_lock.json').read_text(encoding='utf8'))
 assert hashlib.sha256((ROOT/'results/archive_frozen.json').read_bytes()).hexdigest()==lock['archive_sha256']
 targets=runner.selected('screen'); outputs={}; replayed=False
 for t in targets:
  target_rows=[r for r in rows if r['target']==t['id']]; assert len(target_rows)==6
  for r in target_rows:
   comp=[c for c in cards if c['architecture']==t['architecture']]; seed=int(hashlib.sha256((t['id']+':'+str(r['repeat'])).encode()).hexdigest()[:16],16)
   chosen=[] if r['arm']=='none' else (random.Random(seed).sample(comp,2) if r['arm']=='random' else independent_retrieve(t,cards))
   assert [c['source_id'] for c in chosen]==r['source_ids']
   ev=[x for x in calls if (x.get('target'),x.get('arm'),x.get('repeat'))==(t['id'],r['arm'],r['repeat'])]; assert ev and ev[0]['prompt'][0]['content']==runner.editor_prompt(t,screen.card_views(chosen) if chosen else [])
   if r['patch'] is not None:
    valid=[e for e in ev if e['status']=='VALID']; assert len(valid)==1 and runner.parse(json.loads(valid[0]['raw_response'])['choices'][0]['message']['content'])==r['patch']; assert core.evaluate(t,r['patch'])==r['scores']; assert core.digest_state(independent_patch(t['state'],r['patch']))==core.digest_state(core.apply_patch(t['state'],r['patch'])); replayed=True
  sealed=core.load(ROOT/'data/sealed'/f"{t['id']}.pt"); assert sealed['base_hash']==t['base_hash']; base=core.accuracy(core.model_for(t['state']),sealed['final'])
  for r in target_rows:
   active=r['patch'] is not None and r['scores']['accepted']; score=core.accuracy(core.model_for(core.apply_patch(t['state'],r['patch'])),sealed['final']) if active else base
   match=[x for x in observed if (x['target'],x['arm'],x['repeat'])==(t['id'],r['arm'],r['repeat'])]; assert len(match)==1 and abs(match[0]['gain']-(score-base))<1e-9
  outputs[t['id']]={a:statistics.mean(x['gain'] for x in observed if x['target']==t['id'] and x['arm']==a) for a in ('none','random','relevant')}
 assert replayed
 for arm in ('none','random'):
  diffs=[v['relevant']-v[arm] for v in outputs.values()]; mean=statistics.mean(diffs); null=[statistics.mean(d*s for d,s in zip(diffs,signs)) for signs in itertools.product((-1,1),repeat=len(diffs))]; p=sum(x>=mean-1e-12 for x in null)/len(null)
  assert abs(mean-summary['contrasts'][arm]['mean'])<1e-9 and abs(p-summary['contrasts'][arm]['p_one_sided_sign_flip'])<1e-9
  rng=random.Random(20261104); boots=sorted(statistics.mean(rng.choice(diffs) for _ in diffs) for _ in range(20000))
  def q(z):
   pos=(len(boots)-1)*z; low=math.floor(pos); high=math.ceil(pos); return boots[low]+(boots[high]-boots[low])*(pos-low)
  for key,lo,hi in [('ci95',.025,.975),('ci99',.005,.995),('ci97_5_simultaneous_bonferroni',.0125,.9875)]:
   assert all(abs(a-b)<1e-9 for a,b in zip([q(lo),q(hi)],summary['contrasts'][arm][key]))
 assert len(observed)==len(rows)==len(targets)*6
 mechanisms=json.loads((ROOT/'results/screen_mechanisms.json').read_text(encoding='utf8')); assert mechanisms
 m=mechanisms[0]; t=next(x for x in targets if x['id']==m['target']); c=next(x for x in cards if x['source_id']==m['source_id']); sealed=core.load(ROOT/'data/sealed'/f"{t['id']}.pt"); base=core.model_for(t['state']); base_final=core.accuracy(base,sealed['final'])
 states={'raw_delta':{k:v+v.new_tensor(c['realized_raw_delta'][k]) for k,v in t['state'].items()},'program':core.apply_patch(t['state'],{'base_hash':t['base_hash'],'operations':c['patch_program']['operations']})}
 for name,state in states.items():
  model=core.model_for(state); ac0=core.accuracy(base,t['accept']); ac1=core.accuracy(model,t['accept']); gd0=core.accuracy(base,t['guard']); gd1=core.accuracy(model,t['guard']); accepted=ac1>=ac0 and gd1>=gd0-.10; final=core.accuracy(model,sealed['final']) if accepted else base_final
  assert accepted==m[name]['accepted'] and abs(final-m[name]['final_after_gate'])<1e-9
 relevant=[x for x in rows if x['target']==t['id'] and x['arm']=='relevant']; regenerated=[]
 for r in relevant:
  active=r['patch'] is not None and r['scores']['accepted']; regenerated.append(core.accuracy(core.model_for(core.apply_patch(t['state'],r['patch'])),sealed['final']) if active else base_final)
 assert regenerated==m['regenerated_final_after_gate']
 print('PASS: frozen logs, selection/prompt, proposal replay, failure denominator, target gains and paired sign-flip contrasts; bootstrap intervals and one target three mechanisms replayed')
if __name__=='__main__': main()
