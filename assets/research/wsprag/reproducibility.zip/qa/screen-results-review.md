# Screen independent result QA

After official screen opening and before confirm requests, ran `python qa/verify_results.py` with TEMP/TMP in `qa/temp`; exit code 0. The interpreter emitted a location warning but completed.

The script checked opening-marker hashes of proposals, raw model log and journal; recomputed relevant retrieval using independent TF-IDF/RMS code and deterministic random control, checked first actual prompt and valid patch against the returned model response; independently reproduced ADD numeric changes and checked acceptance/guard results. It reconstructed final gains for all 48 proposal rows, including invalid/rejected rows at unedited baseline, and independently recomputed paired mean contrasts, sign-flip p-values, 95%, 99%, and Bonferroni simultaneous intervals. For one target it replayed raw delta, RMS-scaled program, and relevant regenerated proposals under the recorded gate.

Outcome: PASS for these checks. This does not validate the exchangeability assumption, infer generalization beyond this tiny test, establish source-matched mechanism comparisons, or establish confirm results. The interval calculation independently repeats the prespecified seeded bootstrap algorithm; it is not a different statistical method. QA script and official evaluator share model loading and accuracy primitives; patch values and retrieval ranking were independently implemented.

## Post-confirm screen replay

`python scripts/replay_screen.py` ran after confirm with exit 0. It finds a complete-line raw-log prefix whose SHA-256 equals the screen-opening marker, copies inputs into a temporary workspace and overwrites only the temporary log; the independent verifier then passed the same selection, proposal, denominator, contrast, bootstrap and one-target mechanism checks. No original log was modified. The wrapper copies all `data` and `results` into the local temporary workspace, including sealed data; it is suitable for trusted local replay, not a privacy-minimized public workflow. Python emitted an interpreter-location warning despite exit 0.
