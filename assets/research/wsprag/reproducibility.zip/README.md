# E5 WSPRAG: code and experimental evidence

This archive supports the preprint “Can Retrieved Editing Experience Transfer Across Neural Checkpoints? A Controlled Tiny-Network Study.” It contains generated tiny-network data, frozen settings, source code, model request and response logs, results, and independent replay scripts. No large language-model checkpoints are included: the targets are tiny classifiers. The closed editor provider did not expose an immutable model revision, so a future generation run cannot be guaranteed to reproduce responses.

## Contents

- `experiment/`: data generation, restricted patch interface, model proposal drivers and evaluation.
- `config/`, `data/`: frozen settings and generated public/final examples, with identity hashes.
- `logs/`, `results/`, `RESULTS.csv`: complete stored experiment calls, frozen experience library, proposal outcomes and computed summaries, including negative and invalid attempts.
- `qa/`: independent audit reports and reproduction scripts. `scripts/replay_screen.py` reconstructs the raw-log prefix captured before confirmation; `qa/verify_confirm.py` checks confirmation.
- `paper/`: manuscript source and bibliography. For ICLR's style files, download the official ICLR 2027 bundle described in `paper/template/PROVENANCE.md`; that third-party bundle is not included here.
- `PREREGISTRATION.md`, `PROTOCOL_DEVIATIONS.md`, `DAY1_VERDICT.json`: prespecified design, deviations, and scoped verdict.

## Replay

On Windows, using Python 3.13 and versions in `requirements.txt`, run:

```powershell
python scripts/replay_screen.py
python qa/verify_confirm.py
python scripts/export_results.py
```

These commands do not call an editor and do not rerun the experiment. They use the now-public final labels. Never reuse these opened labels as an independent confirmation set. `experiment/EXECUTION.md` explains the one-time opening markers and interruption policy. The original generation code is provided for inspection, not to overwrite the frozen data.

## License and provenance

Original code in `experiment/`, `scripts/`, and `qa/` is released under `LICENSE-CODE` (MIT). The manuscript is licensed by its author under Creative Commons Attribution 4.0 International (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/ . Generated datasets, model outputs, and third-party ICLR style files are not covered by the code license. Model prompts and outputs relate only to generated synthetic target data. The provider model name, usage and unknown billing are recorded without API credentials. See the manuscript for references and limitations.
