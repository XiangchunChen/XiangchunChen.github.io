"""Build result and cost tables only after both evaluation stages finish."""
import csv, json, pathlib, statistics
root=pathlib.Path(__file__).resolve().parents[1]
rows=[]
manifest=json.loads((root/'data/target_manifest.json').read_text(encoding='utf-8'))
for stage,count in [('screen',48),('confirm',72)]:
    path=root/'results'/f'{stage}_final.json'
    if not path.is_file(): raise SystemExit('Cannot export: '+stage+' is incomplete')
    items=json.loads(path.read_text(encoding='utf-8'))
    targets=[x['id'] for x in manifest if x['id'].startswith(stage+'-') and x['eligible']]
    expected={(target,arm,repeat) for target in targets for arm in ('none','random','relevant') for repeat in range(2)}
    actual=[(x['target'],x['arm'],x['repeat']) for x in items]
    if len(items)!=count or len(set(actual))!=count or set(actual)!=expected: raise SystemExit('Incomplete or duplicated '+stage+' results')
    rows.extend({'stage':stage,**item} for item in items)
calls=[json.loads(line) for line in (root/'logs/raw_runs.jsonl').read_text(encoding='utf-8').splitlines()]
summary={}
for stage,arms in {'archive':{'archive'},'screen':{'none','random','relevant'},'confirm':{'none','random','relevant'}}.items():
    subset=[c for c in calls if c.get('target','').startswith(stage+'-') and c['arm'] in arms]
    usage=[json.loads(c['raw_response']).get('usage',{}) if 'raw_response' in c else {} for c in subset]
    result={'calls':len(subset),'statuses':{status:sum(c['status']==status for c in subset) for status in sorted({c['status'] for c in subset})},
        'elapsed_seconds_sum':sum(c.get('elapsed_s',0) for c in subset),
        'median_seconds':statistics.median([c['elapsed_s'] for c in subset]) if subset else None,'billing':'unknown'}
    for name in ('prompt_tokens','completion_tokens'):
        values=[u[name] for u in usage if type(u.get(name)) is int]
        result[name+'_observed_sum']=sum(values) if values else None
        result[name+'_records']=len(values)
        result[name+'_complete_total']=sum(values) if len(values)==len(subset) and values else None
    summary[stage]=result
csv_tmp=root/'RESULTS.csv.tmp'; json_tmp=root/'results/call_costs.json.tmp'
with csv_tmp.open('w',newline='',encoding='utf-8') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
json_tmp.write_text(json.dumps(summary,indent=2),encoding='utf-8')
csv_tmp.replace(root/'RESULTS.csv'); json_tmp.replace(root/'results/call_costs.json')
