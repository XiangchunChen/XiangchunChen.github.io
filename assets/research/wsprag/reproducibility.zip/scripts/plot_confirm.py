"""Render the preregistered confirmation contrasts directly from the summary."""
import json,pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=pathlib.Path(__file__).resolve().parents[1]
s=json.loads((root/'results/confirm_summary.json').read_text(encoding='utf8'))
ids=list(s['target_gains']); y=list(range(len(ids)))
fig,axes=plt.subplots(1,2,figsize=(9.0,5.8),sharey=True,layout='constrained')
for ax,control in zip(axes,['none','random']):
    diffs=[100*(s['target_gains'][i]['relevant']-s['target_gains'][i][control]) for i in ids]
    ax.axvline(0,color='#8c98a6',lw=1)
    ax.scatter(diffs,y,s=34,color='#255b90',zorder=3)
    ax.set_title('Relevant − '+('no experience' if control=='none' else 'random experience'),fontsize=11,fontweight='bold',loc='left')
    ax.set_xlabel('Difference in accuracy gain (percentage points)')
    ax.grid(axis='x',color='#e1e8ee',lw=.7); ax.set_axisbelow(True)
    ax.spines[['top','right','left']].set_visible(False)
    ax.tick_params(axis='y',length=0)
    ax.set_xlim(-0.6,1.4)
    mean=s['contrasts'][control]['mean']*100
    ax.axvline(mean,color='#d17a32',lw=1.5,linestyle='--',label=f'Mean: {mean:+.3f} pp')
    ax.legend(frameon=False,loc='lower right',fontsize=9)
axes[0].set_yticks(y,ids);axes[0].invert_yaxis()
fig.suptitle('Confirmation: differences for each of 12 held-out checkpoints',fontsize=14,fontweight='bold',x=.01,ha='left')
out=root/'site/assets/research/wsprag/confirm-targets.svg';fig.savefig(out,bbox_inches='tight',facecolor='white');print(out)
