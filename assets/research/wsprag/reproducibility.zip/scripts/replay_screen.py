"""Replay pre-confirm screen from the exact raw-log prefix, without mutation."""
import hashlib, json, pathlib, shutil, subprocess, sys, tempfile
root=pathlib.Path(__file__).resolve().parents[1]
marker=json.loads((root/'results/screen_opening.json').read_text(encoding='utf8'))
raw=(root/'logs/raw_runs.jsonl').read_bytes(); h=hashlib.sha256(); offset=0
for line in raw.splitlines(keepends=True):
    offset+=len(line); h.update(line)
    if h.hexdigest()==marker['raw_log_sha256']: break
else: raise SystemExit('Saved screen raw-log prefix cannot be reconstructed')
scratch=root/'qa'/'temp';scratch.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='replay-screen-',dir=scratch) as tmp:
    dest=pathlib.Path(tmp)
    for name in ('experiment','config','data','results','logs'):
        shutil.copytree(root/name,dest/name,ignore=shutil.ignore_patterns('__pycache__','superseded'))
    (dest/'qa').mkdir();shutil.copy2(root/'qa/verify_results.py',dest/'qa/verify_results.py')
    (dest/'logs/raw_runs.jsonl').write_bytes(raw[:offset])
    subprocess.run([sys.executable,str(dest/'qa/verify_results.py')],check=True,cwd=dest)
