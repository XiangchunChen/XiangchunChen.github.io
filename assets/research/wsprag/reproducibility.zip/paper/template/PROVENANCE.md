# Official ICLR template provenance

Retrieved 2026-11-04 from the ICLR 2027 author guidelines: https://iclr.cc/Conferences/2027/AuthorGuidelines . The official style bundle is https://media.iclr.cc/Conferences/ICLR2027/iclr-2027-style-files.zip, SHA-256 `0d940dfa9398ae99a18f24a85a8a683f367204b6af6d17d2899e60a67102529e`.

The guideline lists the full submission deadline as 2026-09-25 AOE, already past at retrieval. Using this template for a paper or preprint is not a conference submission or acceptance. Check the official website for a newer template at actual release time. The author guidelines require disclosure of LLM use for actual ICLR 2027 submissions.
